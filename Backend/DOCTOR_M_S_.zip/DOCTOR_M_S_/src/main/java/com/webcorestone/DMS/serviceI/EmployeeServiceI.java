package com.webcorestone.DMS.serviceI;


public interface EmployeeServiceI {

}
