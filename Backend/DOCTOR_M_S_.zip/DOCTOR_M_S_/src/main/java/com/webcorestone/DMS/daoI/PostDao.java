package com.webcorestone.DMS.daoI;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.webcorestone.DMS.model.PostDetails;
@Repository
public interface PostDao extends JpaRepository<PostDetails, Integer>{

	//@Query("from postDetails where pId=:pId")
	public PostDetails findAllBypId(Integer pId);

	
	

}
